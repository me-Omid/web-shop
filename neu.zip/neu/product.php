<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="product.css">
</head>
<body>
    <?php
        session_start(); 
        $servername = "localhost"; // Server-Adresse (z. B. 127.0.0.1)
        $username = "root";        // Benutzername der Datenbank
        $password = "";            // Passwort (bei XAMPP oft leer)
        $database = "online_shop"; // Name der Datenbank

        $id = $_GET["pid"]; // Produkt id wird in einer Variable gespeichert

        $sql = "SELECT * FROM produkt where PK_produkt_ID = $id"; // sql befehl mit dem man den Produkt mit der $id abrufen kann

        $conn = new mysqli($servername, $username, $password, $database); // Verbindung wird hergestellt

        if ($conn->connect_error) { // es wird überprüft ob es fehler bei der Verbindung gibt
            die("Verbindung fehlgeschlagen: " . $conn->connect_error);
        }
        $result = $conn->query($sql); // SQL-Abfrage ausführen
        if ($result->num_rows > 0){
            $row = $result->fetch_assoc();
        } 

    ?>
    <div id="container">
    <div id="img" style="background-image: url('./Bilder/Produkt_Bilder/<?php echo $row["Bild_Pfad"]; ?>');"></div>
        <div id="beschreibung">
            <div>
                <h1><?php echo($row["Name"]) ?></h1>
                <p><?php echo($row["Beschreibung"]) ?></p>

            </div>
            <div>
                <h3>Preis:<?php echo($row["Preis"]) ?>€</h3>
                <a id="Kaufen" <?php if(isset($_SESSION["PK_Kunde_ID"])){echo('href="./Orders/order.php?pid='.$row["PK_Produkt_ID"]); echo('"');} else{echo("href='./Profile/Anmelden/login.php'");}?> >Kaufen</a>
            </div>

        </div>

    </div>
    
</body>
</html>