<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="suche.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <title>Talahon Tech</title>
    <link rel="icon" href="./Bilder/icons/icon.png" type="image/x-icon">
</head>
<body>
    <header>
            <h1 id="name" style="color: white; text-decoration: none;"><a href="../index.php">Talahon Tech</a></h1>
    </header>

    <center><div id="such_box">
        <form action="./suche.php" method="get">
            <input id="suche" type="text" placeholder="Suche" name="gesucht">
            <input id="submit" type="submit" value="Suchen">
        </form>
    </div></center>


    <center><h3><?php
                if(isset($_GET["gesucht"]) && $_GET["gesucht"] != null){
                    echo("passende Inhalte zu ". $_GET["gesucht"]);
                    $name = $_GET['gesucht'];
                    $sql1 = "SELECT * FROM produkt where Name like '%$name%';";
                }
                else if(!isset($_GET["gesucht"]) || $_GET["gesucht"] == null)
                {
                    echo("Unser Sortiment");
                    $sql1 = "SELECT * FROM produkt where Lagerbestand > 0;";
                }

    ?></h3></center>


    <main id="produkt_kontainer">
        <div id="product_box">
        <?php
                $servername = "localhost"; // Server-Adresse (z. B. 127.0.0.1)
                $username = "root";        // Benutzername der Datenbank
                $password = "";            // Passwort (bei XAMPP oft leer)
                $database = "online_shop";      // Name der Datenbank

                $conn = new mysqli($servername, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Verbindung fehlgeschlagen: " . $conn->connect_error);
                }
                $result2 = $conn->query($sql1); // SQL-Abfrage ausführen
                if ($result2->num_rows > 0) {
                    while ($row2 = $result2->fetch_assoc()) {
                        echo('<a href="../product.php?pid='.$row2["PK_Produkt_ID"].'" class="p">'
                                . '<div id="image" style="background-image: url(../Bilder/Produkt_Bilder/'.$row2["Bild_Pfad"].'); background-size: cover; background-position: center;">
                                </div>'
                                . '<div id="info">'.
                                    '<div id="name">'
                                        . $row2["Name"] . 
                                    '</div>'.
                                    '<div id="name">'
                                    . $row2["Preis"] . "€".
                                '</div>'
                                    ."inkl. MwSt. zzgl. Versand"
                                    .
                                '</div>'.
                                
                            '</a>');
                    }
                }
        ?>
        </div>
    </main> 
</body>
</html>