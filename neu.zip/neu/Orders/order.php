<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>order</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <?php 
        session_start();
        $uid = $_SESSION["PK_Kunde_ID"];
        $pid = $_GET["pid"];


        $servername = "localhost"; // Server-Adresse (z. B. 127.0.0.1)
        $username = "root";        // Benutzername der Datenbank
        $password = "";            // Passwort (bei XAMPP oft leer)
        $database = "online_shop";      // Name der Datenbank

        $conn = new mysqli($servername, $username, $password, $database);

        $sql_select = "SELECT * FROM kunde where PK_kunde_ID  = $uid;";

        if ($conn->connect_error) {
            die("Verbindung fehlgeschlagen: " . $conn->connect_error);
        }
        $result = $conn->query($sql_select); // SQL-Abfrage ausführen

        if ($result->num_rows > 0){
            $row = $result->fetch_assoc();
            $bestelldatum = date("Y-m-d");

            $sql_insert = "INSERT INTO bestellung (Bestelldatum, Lieferadresse_Strasse_nr, Lieferadresse_PLZ_Ort, 
            Gesampreis, FK_Kunde_ID, FK_Produkt_ID) 
            VALUES ('$bestelldatum', '{$row["Strasse_HausNr"]}', '{$row["PLZ_ORT"]}', '0', '$uid', '$pid');";

            $conn->query($sql_insert); // SQL-Abfrage ausführen

            echo("<h1 id ='msg'>Ihre Bestellung war Erfolgreich.</h1>");
            // Nach einer Sekunde wird der Nutzer zur index.php weitergeleitet 
            echo"<script>
                    setTimeout(function() {window.location.href = '../index.php';}, 1500); 
                </script>";

        }
        else{
            echo("Es ist ein Fehler Aufgetreten.");
        }
    ?>

    <style>
        html{
            font-family: "Comic Neue", cursive;
            font-weight: 400;
            font-style: normal; 
        }
        body{
            margin:0;
        }
        #msg{
            display: flex; justify-content: center; align-items: center;
            width: 100dvw; height:100dvh;
            margin:0;
        }
    </style>
    
</body>
</html>
