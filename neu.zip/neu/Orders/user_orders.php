<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="user_orders.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <title>Talahon Tech</title>
    <link rel="icon" href="../Bilder/icons/icon.png" type="image/x-icon">
</head>
<body>
    <header>
            <h1 style="color: white; text-decoration: none;"><a href="../index.php">Talahon Tech</a></h1>
            <div id="icons">
                <a href="../Suche/suche.php" id="suche"></a>
                <div id="einkaufswagen"></div>
                <?php 
                session_start();
                if(isset($_SESSION["PK_Kunde_ID"])){
                    echo("<a href='../Profile/profile.php ' id='user_icon'></a>");
                }
                else{
                    echo("<a href='../Profile/Anmelden/login.php' id='user_icon'></a>");
                }
                ?>
            </div>
    </header>

    <center><h1>Bestellungen</h1></center>
    <center><main>
            <?php
                $servername = "localhost"; // Server-Adresse (z. B. 127.0.0.1)
                $username = "root";        // Benutzername der Datenbank
                $password = "";            // Passwort (bei XAMPP oft leer)
                $database = "online_shop";      // Name der Datenbank

                $uid = $_SESSION["PK_Kunde_ID"];

                $conn = new mysqli($servername, $username, $password, $database);

                $sql_select = "SELECT Bestelldatum,Lieferadresse_Strasse_nr,Lieferadresse_PLZ_Ort,Gesampreis, FK_Produkt_ID, Bild_Pfad, Name,Preis
                            FROM bestellung inner join produkt on bestellung.FK_Produkt_ID = produkt.PK_produkt_ID
                            where FK_Kunde_ID = $uid;";

                if ($conn->connect_error) {
                    die("Verbindung fehlgeschlagen: " . $conn->connect_error);
                }
                $result = $conn->query($sql_select); // SQL-Abfrage ausführen
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo('
                            <div id="order_box">
                                <div id="img" style="background-image: url(../Bilder/Produkt_Bilder/'.$row["Bild_Pfad"].');"></div>
                                <div id="description">
                                    <p>Name: '.$row["Name"].'</p>
                                    <p>bestellt am: ' . $row["Bestelldatum"].'</p>
                                    <p>Preis: '.$row["Preis"].'€</p>
                                </div>
                            </div>
                        ');
                    }
                }
                else{
                    echo("<center><hp>Keine Bestellungen vorhanden.</hp></center>");
                }
        ?>
    </main></center>
</body>
</html>