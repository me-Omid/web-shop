<?php 
            $name = $_POST["name"];
            $beschreibung = $_POST["Beschreibung"];
            $preis = $_POST["preis"];
            $kategorie = $_POST["kategorie"];
            $lagerbestand = $_POST["lagerbestand"];

            session_start();
            $Seller_ID = $_SESSION["Seller_ID"];

            $servername = "localhost"; // Server-Adresse (z. B. 127.0.0.1)
            $username = "root";        // Benutzername der Datenbank
            $password = "";            // Passwort (bei XAMPP oft leer)
            $database = "online_shop";      // Name der Datenbank
        
            $sql = "INSERT INTO `produkt` (`Name`, `Beschreibung`, `Preis`, `Lagerbestand`, FK_Kategorie_ID, `FK_Seller_ID`) 
            VALUES ('$name', '$beschreibung', '$preis', '$lagerbestand', $kategorie, '$Seller_ID');";

            $sql_Select = "Select * from produkt where Name = '$name' AND Beschreibung= '$beschreibung' AND Preis = '$preis' 
            AND FK_Kategorie_ID = '$kategorie' AND FK_Seller_ID = '$Seller_ID';";
            $conn = new mysqli($servername, $username, $password, $database);
        
            if ($conn->connect_error) {
                die("Verbindung fehlgeschlagen: " . $conn->connect_error);
                header("Location: ./index.php");
            }

            $result = $conn->query($sql); // SQL-Abfrage ausführen
            //header("Location: ./seller.php");
            $result = $conn->query($sql_Select);
            $row = $result->fetch_assoc();
            
            $produkt_ID = $row["PK_Produkt_ID"];




            if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
                // Zielordner für das Bild
                $ordner = '../Bilder/Produkt_Bilder/';

                // Extrahiere die Dateiendung der hochgeladenen Datei (z. B. .png, .jpg)
                $fileExtension = pathinfo($_FILES['picture']['name'], PATHINFO_EXTENSION);

                // Neuer Dateiname: Produkt-ID als Name und Dateiendung beibehalten
                $dateiName = $produkt_ID . '.' . $fileExtension;

                // Zielpfad für das Bild
                $zielPfad = $ordner . $dateiName;

                // Bild verschieben und Erfolg prüfen
                if (move_uploaded_file($_FILES['picture']['tmp_name'], $zielPfad)) {
                    echo "Das Bild wurde erfolgreich hochgeladen: " . $dateiName;
                } else {
                    echo "Fehler beim Verschieben des Bildes.";
                }
            }


            $sql_update_image_name = "UPDATE produkt SET Bild_Pfad = '$dateiName' WHERE (PK_Produkt_ID = $produkt_ID);";
            $result = $conn->query($sql_update_image_name);
            header("Location: ./seller.php");


?>