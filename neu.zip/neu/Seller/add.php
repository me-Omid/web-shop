<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD Product</title>
    <link rel="stylesheet" href="./css/add.css">
</head>
<body>
    <?php
        if(isset($_POST["submit"])){
            $file_name = $_FILES["imgae"]["name"];
            $tempname = $_FILES["imgae"]["temp_name"];
            
        }
    ?>
    <div id="add_bar">
        <form action="addit.php" method = "post" enctype="multipart/form-data">
            <input id="suche" type="text" value="Name" name = "name">
            <input id="suche" type="text" value="Preis" name = "preis">
            <input id="suche" type="text" value="Lagerbestand" name = "lagerbestand">
            <select name="kategorie">
                <option value="1">PC Komponente</option>
                <option value="2">Play Station</option>
                <option value="3">Gaming Zubehör</option>
                <option value="4">Spiele</option>
                <option value="5">Filme & Serien</option>
                <option value="6">Sonstiges</option>
            </select>
            <input type="file" name="picture" id="">
            <textarea name="Beschreibung" id="" Placeholder="Beschreibung...."></textarea>
            <input id="submit" type="submit" value="Hinzufügen">
        </form>
    </div>
</body>
</html>