<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" href="./css/index.css">
</head>
<body>
    <?php
        session_start();
        $_SESSION["Seller_ID"] = "0";
    ?>
    <div id="container">
        <div id="left">
            <div id="logo"><strong>Talahon-Tech Alman co. KG</strong></div>
            <div id="privacy">Willkommen bei Talahon-Tech ihr Online Händler</div>
        </div>
        <div id="right">
            <h1>Login/Register</h1>
            <form id="loginForm" method="post" action="login.php">
                <input id="email" type="email" name="mail" placeholder="E-Mail Adresse" required>
                <input id="password" type="password" name="password" placeholder="Passwort" required>
                <button id="submitBtn" type="submit">Login</button>
            </form>
        </div>
    </div>
    
</body>
</html>