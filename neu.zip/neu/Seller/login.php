<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php
        // Eingabewerte aus dem Formular holen
        $mail = $_POST["mail"];
        $pass = $_POST["password"];


        $pass_in_hash = md5($pass);

        // Prüfen, ob die Eingabewerte gesetzt sind
        if (empty($mail) || empty($pass)) {
            header("Location: ./index.php"); // Zurück zur Login-Seite
            exit(); // Script beenden
        }

        // Datenbank-Verbindung
        $servername = "localhost"; 
        $username = "root";       
        $password = "";           
        $database = "online_shop";    

        // Verbindung zur Datenbank herstellen
        $conn = new mysqli($servername, $username, $password, $database);

        // Überprüfen, ob die Verbindung erfolgreich war
        if ($conn->connect_error) {
            die("Verbindung fehlgeschlagen: " . $conn->connect_error);
        }

        // SQL-Statement ohne Anführungszeichen um Platzhalter
        $sql = "SELECT * FROM seller WHERE E_Mail = ? AND Passwort = ?";

        // Vorbereitetes Statement
        $result = $conn->prepare($sql);
        if ($result === false) {
            echo "Fehler bei der Vorbereitung des Statements!";
            exit(); // Script beenden
        }

        // Parameter an das Statement binden
        $result->bind_param("ss", $mail, $pass_in_hash);

        // Statement ausführen
        $result->execute();

        // Ergebnisse holen
        $result_get = $result->get_result();

        // Überprüfen, ob ein Ergebnis zurückgegeben wurde
        if ($result_get->num_rows > 0) {
            $row = $result_get->fetch_assoc(); // Erste Zeile des Ergebnisses holen
            $Seller_ID = $row["PK_Seller_ID"]; // Seller_ID aus der Tabelle holen

            // Session starten und ID speichern
            session_start();
            $_SESSION["Seller_ID"] = $Seller_ID;

            // Weiterleitung zur seller.php
            header("Location: ./seller.php");
            exit(); // Script beenden
        } else {
            // Kein Ergebnis, also zurück zur Login-Seite
            echo("Kein Nutzer Vorhanden.");
            header("Location: ./index.php");
            exit(); // Script beenden
        }

        // Verbindung schließen
        $conn->close();
    ?>

</body>
</html>
