<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/Seller_orders.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <title>Talahon Tech</title>
    <link rel="icon" href="../Bilder/icons/icon.png" type="image/x-icon">
</head>
<body>
    <header id="head">
        <?php 
            session_start();
            $seller_name = $_SESSION["Seller_Name"];
            $seller_id = $_SESSION["Seller_ID"];

            if(isset($seller_id) != true){
                header("Location: ./index.php");
            }
        ?>
        <a href="./Seller.php" id="pf"><?php echo ("<h1>".$seller_name. "</h1>"); ?> </a>
        <form id="sucheform" action="" method = "get">
            <input id="suche" type="text" value="Suche" name = "suche">
            <input id="submit" type="submit" value="Suchen">
            <a id="einkaufswagen" href="./Seller_orders.php"></a>
            <a href="./add.php" id="add"></a>
        </form>
        
    </header>

    <center><h1>Bestellungen</h1></center>
    <center><main>
            <?php
                $servername = "localhost"; // Server-Adresse (z. B. 127.0.0.1)
                $username = "root";        // Benutzername der Datenbank
                $password = "";            // Passwort (bei XAMPP oft leer)
                $database = "online_shop";      // Name der Datenbank


                $conn = new mysqli($servername, $username, $password, $database);

                $sql_select = "SELECT Bestelldatum,Lieferadresse_Strasse_nr,Lieferadresse_PLZ_Ort,Gesampreis, 
                FK_Produkt_ID, Bild_Pfad, produkt.Name,Preis, Vorname, Nachname,IBAN
                FROM bestellung inner join produkt on bestellung.FK_Produkt_ID = produkt.PK_produkt_ID
                inner join kunde on bestellung.FK_Kunde_ID = PK_Kunde_ID
                where FK_Seller_ID = '$seller_id' ORDER BY PK_Bestellung_ID DESC"; //DESC Die Neuste Bestellungen zuerst

                if ($conn->connect_error) {
                    die("Verbindung fehlgeschlagen: " . $conn->connect_error);
                }
                $result = $conn->query($sql_select); // SQL-Abfrage ausführen
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo('
                            <div id="order_box">
                                <div id="img" style="background-image: url(../Bilder/Produkt_Bilder/'.$row["Bild_Pfad"].');"></div>
                                <div id="description">
                                    <p>Produkt Name: '.$row["Name"].'</p>
                                    <p>bestellt von : ' . $row["Vorname"]." ".$row["Nachname"].'</p>
                                    <p>IBAN : ' . $row["IBAN"].'</p>
                                    <p>Strasse Haus Nr. : '.$row["Lieferadresse_Strasse_nr"].'</p>
                                    <p>PLZ Ort : ' . $row["Lieferadresse_PLZ_Ort"].'</p>
                                    <h3>Preis: '.$row["Preis"].'€</h3>
                                </div>
                            </div>
                        ');
                    }
                }
                else{
                    echo("<center><hp>Keine Bestellungen vorhanden.</hp></center>");
                }
        ?>
    </main></center>
</body>
</html>