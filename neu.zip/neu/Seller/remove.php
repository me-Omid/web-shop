<?php 

    $id = $_GET["id"];
    $Bild_Ordner = "../Bilder/Produkt_Bilder/";

    $servername = "localhost"; // Server-Adresse (z. B. 127.0.0.1)
    $username = "root";        // Benutzername der Datenbank
    $password = "";            // Passwort (bei XAMPP oft leer)
    $database = "online_shop";      // Name der Datenbank

    $sql = "DELETE FROM `produkt` WHERE (`PK_Produkt_ID` = '$id');";
    $sqlselect = "Select * from produkt where PK_Produkt_ID = '$id';";
    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Verbindung fehlgeschlagen: " . $conn->connect_error);
        header("Location: index.php");
    }
    // Produtk Bild Löschen
    $result = $conn->query($sqlselect);
    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        $bildname = $row["Bild_Pfad"];
        if (!unlink($Bild_Ordner.$bildname)) {
            echo("Fehler beim Löschen der Datei: " . $bildname);
            $result = $conn->query($sql); 
            header("Location: Seller.php");
        } else {
            echo "Das Bild wurde erfolgreich gelöscht";
             // Produkt Daten Löschen Läschen
             $result = $conn->query($sql); 
             header("Location: Seller.php");
        }
    }
    else{
        echo("Keine Daten Vorhanden!!");
    }

    

?>