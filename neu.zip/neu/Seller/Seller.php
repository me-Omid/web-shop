<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/Seller.css">
    <title>Seller</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap" rel="stylesheet">
</head>
<body>
    <?php
        session_start();
        $seller_ID = $_SESSION["Seller_ID"];

        function dbVerbindung() {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "online_shop";
        
            // Verbindung erstellen
            $conn = new mysqli($servername, $username, $password, $database);
        
            // Verbindung auf Fehler prüfen
            if ($conn->connect_error) {
                die("Verbindung fehlgeschlagen: " . $conn->connect_error);
            }
        
            return $conn; // Die Verbindung wird zurückgegeben
        }

        $sql = "SELECT * FROM seller where PK_Seller_ID = '$seller_ID';";
        $sql2 = "SELECT * FROM produkt where FK_Seller_ID = '$seller_ID';";

        $conn = dbVerbindung();

        if ($conn->connect_error) {
            die("Verbindung fehlgeschlagen: " . $conn->connect_error);
            header("Location: index.php");
        }
        $result = $conn->query($sql); // SQL-Abfrage ausführen
        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            $_SESSION["Seller_Name"] = $row["Name"];
            $_SESSION["Seller_ID"] = $row["PK_Seller_ID"];
        }
        else{
            header("Location: index.php");
        }
    ?>

    <header id="head">
        <div id="pf"><?php echo ("<h1>".$row["Name"]. "</h1>"); ?> </div>
        <form id="sucheform" action="" method = "get">
            <input id="suche" type="text" value="Suche" name = "suche">
            <input id="submit" type="submit" value="Suchen">
            <a id="einkaufswagen" href="./Seller_orders.php"></a>
            <a href="./add.php" id="add"></a>
        </form>
        
    </header>

    <center><div id="banner"></div></center>

    <main>

        <?php

            if(!empty($_GET["suche"])){
                $suchinhalt = $_GET["suche"];
                if($suchinhalt != null){
                    $sql2 = "SELECT * FROM produkt where FK_Seller_ID = '$seller_ID' and Name Like '%$suchinhalt%';";
                }
            }

            $result = $conn->query($sql2); // SQL-Abfrage ausführen
            if($result->num_rows > 0){
                $anzahl_produkte = $result->num_rows;
                $i = 0;
                while($anzahl_produkte > $i){
                    $row = $result->fetch_assoc();
                    $i++;
                    $bild_pfad = $row['Bild_Pfad'];

                    // Sehr Unverständlich
                    echo(
                        "<div class='product_card'>". 
                            "<div class='product_image' style='background-image: url(../Bilder/Produkt_Bilder/".$bild_pfad."); background-size: cover; background-position: center;'>"."</div>".
                            "<div class='product_info'>".
                                "<div id='name_lagerbestand'>".
                                    "<p Style='margin: 0;'>"."Name:".$row["Name"]. "</p>".
                                    "<p Style='margin: 0;'>"."Lagerbestand:".$row["Lagerbestand"]. "</p>".
                                "</div>".
                                "<a href='remove.php?id=".$row["PK_Produkt_ID"]."' id='delete'></a>".
                            "</div>".
                        "</div>"
                    );
                }
            }
        ?>
    </main>
    
</body>
</html>