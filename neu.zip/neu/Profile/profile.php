<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body>
    <div id="picture"></div>
    <?php 
        session_start();
        $vorname = $_SESSION["Vorname"];
        $nachname = $_SESSION["Nachname"];
        $id = $_SESSION["PK_Kunde_ID"];

        $servername = "localhost"; // Server-Adresse
        $username = "root";        // Benutzername der Datenbank
        $password = "";            // Passwort (bei XAMPP oft leer)
        $database = "online_shop";      // Name der Datenbank
        $conn = new mysqli($servername, $username, $password, $database);

        $sql = "SELECT * FROM Kunde where PK_Kunde_ID = '$id';";

        if ($conn->connect_error) {
            die("Verbindung fehlgeschlagen: " . $conn->connect_error);
        }
        $result = $conn->query($sql); // SQL-Abfrage ausführen
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo("<h3>".$row["Vorname"]." ". $row["Nachname"]."</h3>");
            echo("<p> E-Mail: ".$row["E_Mail"]."</p>");
            echo("<p> Straße Haus Nr. : ".$row["Strasse_HausNr"]."</p>");
            echo("<p> PLZ Ort: ".$row["PLZ_ORT"]."</p>");
            echo("<p> IBAN: ".$row["IBAN"]."</p>");
            echo("<p> Telefon Nummer: ".$row["Telefon Nummer"]."</p>");
        }

    ?>
    <a href="logout.php">Ausloggen</a>

    
</body>
</html>
