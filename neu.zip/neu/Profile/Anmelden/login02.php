<?php
    $email = $_POST["E_Mail"];
    $pass = $_POST["pass"];

    $servername = "localhost"; // Server-Adresse 
    $username = "root";        // Benutzername der Datenbank
    $password = "";            // Passwort: Wir haben kein Passwort
    $database = "online_shop"; // Name der Datenbank

    $sql = "Select * from kunde where Passwort = '$pass' AND E_Mail = '$email'";
    

    if(isset($email) && isset($pass)){
        $conn = new mysqli($servername, $username, $password, $database);

        if ($conn->connect_error) {
            die("Verbindung fehlgeschlagen: " . $conn->connect_error);
        }

        $result = $conn->query($sql); // SQL-Abfrage ausführen
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo($row["Vorname"]);
            session_start();
            $_SESSION["PK_Kunde_ID"] = $row["PK_Kunde_ID"];
            $_SESSION["Vorname"] = $row["Vorname"];
            $_SESSION["Nachname"] = $row["Nachname"];
            $_SESSION["E_Mail"] = $row["E_Mail"];

            header("Location: ../../index.php");
        }
    }






?>