<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login.css">
    <script src="login.js"></script>
</head>
<body>

    <div id="container">
    <div id="left">
      <div id="logo"><strong>Talahon-Tech Alman co. KG</strong></div>
      <div id="privacy">Willkommen bei Talahon-Tech ihr Online Händler</div>
    </div>
    <div id="right">
        <h1>Login/Register</h1>
        <form id="loginForm" method="POST" action="login02.php">
            <input id="email" type="email" name="E_Mail" placeholder="E-Mail Adresse" required>
            <input id="password" type="password" name="pass" placeholder="Passwort" required>
            <button id="submitBtn" type="submit">Login</button>
        </form>
        <a href="../Registrieren/registrieren.php">Registrieren</a>
    </div>
  </div>


    
    
</body>
</html>

