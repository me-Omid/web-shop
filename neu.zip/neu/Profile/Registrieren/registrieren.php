<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="registrieren.css">
</head>
<body>
    <form action="./registrierung.php" method="post">
        <input type="text" name="Vorname" Placeholder="Vorname" id="">
        <input type="text" name="Nachname" Placeholder="Nachname" id="">
        <input type="mail" name="E_Mail" Placeholder="E-Mail" id="">
        <input type="password" name="Pass" Placeholder="Passwort" id="">
        <input type="text" name="Str_Haus_NR" Placeholder="Straße und Hausnummer" id="">
        <input type="text" name="PLZ_ORT" Placeholder="Postleitzahl/Ort" id="">
        <input type="text" name="Telefonnummer" Placeholder="Telefon Nummer" id="">
        <input type="text" name="iban" Placeholder="IBAN" id="">
        <input type="file" name="picture" id="">
        <input id="reg"type="submit" value="Registrieren">
    </form>
</body>
</html>