<?php

    $vorname = $_POST["Vorname"];
    $nachname = $_POST["Nachname"];
    $e_mail = $_POST["E_Mail"];
    $pass = $_POST["Pass"];
    $str_haus_nr = $_POST["Str_Haus_NR"];
    $plz_ort = $_POST["PLZ_ORT"];
    $telefonnummer = $_POST["Telefonnummer"];
    $iban = $_POST["iban"];



    $sql = "INSERT INTO kunde (`Vorname`, `Nachname`, `E_Mail`, `Passwort`, `PLZ_ORT`, `Strasse_HausNr`, `Telefon Nummer`, `IBAN`) 
    VALUES ('$vorname', '$nachname', '$e_mail', '$pass', '$plz_ort', '$str_haus_nr', '$telefonnummer', '$iban')";

    $sql_select = "Select * from kunde where Vorname = '$vorname' and Nachname ='$nachname'
     and E_Mail ='$e_mail' and Passwort= '$pass' and  PLZ_ORT = '$plz_ort';";


    $servername = "localhost"; // Server-Adresse 
    $username = "root";        // Benutzername der Datenbank
    $password = "";            // Passwort: Wir haben kein Passwort
    $database = "online_shop"; // Name der Datenbank
    

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Verbindung fehlgeschlagen: " . $conn->connect_error);
    }
    $result = $conn->query($sql_select); // Überprüfen ob es den Nutzer schon gibt
    if ($result->num_rows > 0) {
        echo("fehlgeschlagen:");
        echo("Sie haben bereits ein Konto");
    }
    else{
            $conn->query($sql); // Nutzer Hinzufügen
        }


?>